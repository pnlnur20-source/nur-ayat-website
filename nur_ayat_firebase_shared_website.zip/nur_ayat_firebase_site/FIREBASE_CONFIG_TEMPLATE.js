export const firebaseConfig = {
  apiKey: "AIzaSyDOrMQnyNPHrm1xArxXmpOfZ3Yj2Le9hjU",
  authDomain: "nurayatweb.firebaseapp.com",
  projectId: "nurayatweb",
  storageBucket: "nurayatweb.firebasestorage.app",
  messagingSenderId: "792356463461",
  appId: "1:792356463461:web:352d9206dc909cae69f78c",
  measurementId: "G-8N47TWNSCH"
};
